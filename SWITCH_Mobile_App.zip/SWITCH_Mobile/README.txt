SWITCH Mobile — installable web app (PWA)

INSTALL ON YOUR PHONE
Open https://switch-life-yuan.cometmink22.chatgpt.site on your phone and sign in with the owning ChatGPT account if requested.
iPhone: open in Safari > Share > Add to Home Screen > Add. Keep Open as Web App enabled if shown.
Android: open in Chrome > browser menu > Install app / Add to Home screen. Alternatively use More > Install SWITCH inside the app.
Launch SWITCH using its home-screen icon.

ABOUT THIS PACKAGE
This ZIP contains the editable PWA source, app icons, manifest and service worker. It is not an APK or IPA installer. Do not try to install the ZIP as an Android package.
To preview the interface on a computer, unzip and open index.html. Installability and service-worker offline support require HTTPS hosting (localhost is accepted for development). Opening a local file does not enable installation or service-worker caching.

FEATURES
Mobile bottom tabs: Today, Schedule, Plan, Resources, More.
More: Goals, Reflection, Preferences and installation help.
English interface, touch-sized controls, bottom-sheet dialogs, safe-area spacing.
Dated tasks, goals, resource inventory, editable planning previews, reflection journal, JSON backup/import.

OFFLINE AND DATA
Open online first and allow the app files to download. Offline support depends on successful service-worker installation and browser support. Authentication and first-time access still require internet. Offline behavior has not been verified on a physical phone.
Data stays in the current device/browser. Installed apps can have separate storage on some platforms. Export a backup in Preferences before moving between environments; import it in the app if needed.
This prototype uses local planning rules, not a connected language model. It does not provide push reminders, background scheduling, cloud sync, or verified travel/carbon estimates.

NATIVE DISTRIBUTION
No signed native iOS or Android package is included. App Store/TestFlight or native Android distribution requires a separate platform build and signing workflow.
