const CACHE='switch-mobile-v1';
const ROOT=new URL('./',self.location.href);
const SHELL=['index.html','style.css','app.js','mobile.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
// Cache only explicit app assets, never sign-in pages or authentication requests.
self.addEventListener('install',event=>event.waitUntil((async()=>{const cache=await caches.open(CACHE);await Promise.all(SHELL.map(async path=>{const url=new URL(path,ROOT);const response=await fetch(url,{cache:'reload',redirect:'error'});if(!response.ok)throw new Error('Asset unavailable: '+path);if(path==='index.html'){const body=await response.clone().text();if(!body.includes('id="mobile-nav"'))throw new Error('App shell not accessible')}await cache.put(url,response)}));await self.skipWaiting()})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{for(const key of await caches.keys())if(key.startsWith('switch-mobile-')&&key!==CACHE)await caches.delete(key);await self.clients.claim()})()));
self.addEventListener('fetch',event=>{const req=event.request,url=new URL(req.url);if(req.method!=='GET'||url.origin!==ROOT.origin)return;
 if(req.mode==='navigate'){
  if(![ROOT.pathname,new URL('index.html',ROOT).pathname].includes(url.pathname))return;
  event.respondWith(fetch(req).catch(async()=>{const cache=await caches.open(CACHE);return await cache.match(new URL('index.html',ROOT))||new Response('Connect to the internet and open SWITCH once before using it offline.',{status:503,headers:{'Content-Type':'text/plain'}})}));return;
 }
 if(SHELL.some(p=>new URL(p,ROOT).href===url.href))event.respondWith(caches.open(CACHE).then(async cache=>await cache.match(req)||fetch(req)));
});
